package network

//Peer save peer information
type Peer struct {
	Sid          int
	Addr         string
	Port         int
	Portresponse int
}
