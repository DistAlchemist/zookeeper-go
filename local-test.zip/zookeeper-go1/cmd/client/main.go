package main

import (
	"zookeepergo/client"
)

func main() {
	client.Start()
}
