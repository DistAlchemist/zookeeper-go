package main

import (
	"zookeepergo/server"
)

func main() {
	var Server1 server.Server
	Server1.Start()
}
